import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Filter } from "lucide-react";
import { Link } from "wouter";
import HeroSection from "@/components/HeroSection";
import ToolCard from "@/components/ToolCard";
import BlogCard from "@/components/BlogCard";
import SectionHeader from "@/components/SectionHeader";
import { getTrendingTools, getNewTools, getTopRatedTools, categories } from "@/data/tools";
import { blogPosts } from "@/data/blog";

const statItems = [
  { value: "100+", label: "AI Tools", color: "text-emerald-600" },
  { value: "12", label: "Categories", color: "text-indigo-600" },
  { value: "50K+", label: "Monthly Users", color: "text-orange-600" },
  { value: "4.8★", label: "Avg Rating", color: "text-pink-600" },
];

export default function HomePage() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const trending = getTrendingTools();
  const newTools = getNewTools();
  const topRated = getTopRatedTools();

  return (
    <div className="min-h-screen bg-white">
      <HeroSection />

      <div className="border-t border-gray-100 bg-gradient-to-r from-gray-50/80 via-white to-gray-50/80 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
            {statItems.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="text-center"
              >
                <p className={`text-3xl font-extrabold ${stat.color}`}>{stat.value}</p>
                <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="🔥 Trending"
            badgeColor="orange"
            title="Trending AI Tools"
            subtitle="The most popular AI tools this week based on user activity and reviews."
            action={{ label: "View all trending", href: "/tools?filter=trending" }}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {trending.map((tool, i) => (
              <ToolCard key={tool.id} tool={tool} index={i} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="🆕 New Tools"
            badgeColor="indigo"
            title="Just Launched"
            subtitle="Fresh AI tools that just landed — be the first to try them."
            action={{ label: "View all new tools", href: "/tools?filter=new" }}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {newTools.map((tool, i) => (
              <ToolCard key={tool.id} tool={tool} index={i} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="⭐ Top Rated"
            badgeColor="sky"
            title="Top Rated Tools"
            subtitle="Highest-rated AI tools based on thousands of user reviews."
            action={{ label: "View all top rated", href: "/tools?filter=top" }}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {topRated.map((tool, i) => (
              <ToolCard key={tool.id} tool={tool} index={i} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-br from-emerald-50 via-white to-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full border bg-white border-gray-200 text-gray-600 mb-4">
              🗂️ Browse by Category
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-3">Explore All Categories</h2>
            <p className="text-gray-500">Find the right AI tool for every job</p>
          </motion.div>

          <div className="flex flex-wrap gap-2 justify-center mb-8">
            {categories.map((cat, i) => (
              <motion.button
                key={cat}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04 }}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all border ${
                  activeCategory === cat
                    ? "bg-emerald-500 text-white border-emerald-500 shadow-md shadow-emerald-200"
                    : "bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                }`}
              >
                {cat}
              </motion.button>
            ))}
          </div>

          <div className="relative max-w-xl mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search all AI tools..."
              className="w-full pl-12 pr-4 py-4 rounded-2xl border border-gray-200 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-300 focus:border-emerald-400 text-gray-800 shadow-sm"
            />
            <button className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-500 hover:bg-gray-100 transition-colors">
              <Filter className="w-3.5 h-3.5" />
              Filter
            </button>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            badge="📚 Blog"
            badgeColor="pink"
            title="Latest Articles"
            subtitle="Expert guides and insights to help you get the most out of AI tools."
            action={{ label: "View all articles", href: "/blog" }}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {blogPosts.slice(0, 6).map((post, i) => (
              <BlogCard key={post.id} post={post} index={i} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative overflow-hidden bg-gradient-to-br from-emerald-500 via-emerald-600 to-indigo-600 rounded-3xl p-10 sm:p-16 text-center shadow-2xl shadow-emerald-200"
          >
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(255,255,255,0.15)_0%,_transparent_60%)]" />
            <div className="relative">
              <span className="inline-block text-4xl mb-4">🚀</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-4">
                Know a great AI tool?
              </h2>
              <p className="text-emerald-100 text-lg mb-8 max-w-xl mx-auto">
                Help the community discover new tools. Submit your favorite AI tool and get it featured.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link
                  href="/submit"
                  className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-base font-semibold text-emerald-700 bg-white rounded-xl hover:bg-emerald-50 transition-colors shadow-md"
                >
                  Submit a Tool →
                </Link>
                <Link
                  href="/tools"
                  className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-base font-semibold text-white border border-white/30 rounded-xl hover:bg-white/10 transition-colors"
                >
                  Browse All Tools
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
