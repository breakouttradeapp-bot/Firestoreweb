import { motion } from "framer-motion";
import { TrendingUp, Star, Sparkles, Search, ArrowRight, Zap } from "lucide-react";
import { Link } from "wouter";
import { getFeaturedTools } from "@/data/tools";

const floatingBadges = [
  { icon: <TrendingUp className="w-3.5 h-3.5" />, label: "Trending", color: "bg-orange-50 border-orange-200 text-orange-700" },
  { icon: <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />, label: "Top Rated", color: "bg-amber-50 border-amber-200 text-amber-700" },
  { icon: <Sparkles className="w-3.5 h-3.5" />, label: "New Tools", color: "bg-indigo-50 border-indigo-200 text-indigo-700" },
];

export default function HeroSection() {
  const featured = getFeaturedTools();

  return (
    <section className="relative overflow-hidden bg-white pt-24 pb-16">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(16,185,129,0.05)_0%,_transparent_50%),_radial-gradient(ellipse_at_bottom_left,_rgba(99,102,241,0.05)_0%,_transparent_50%)]" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-emerald-200 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex flex-wrap gap-2 mb-6"
            >
              {floatingBadges.map((badge, i) => (
                <motion.span
                  key={badge.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.1 + i * 0.1 }}
                  className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full border ${badge.color}`}
                >
                  {badge.icon}
                  {badge.label}
                </motion.span>
              ))}
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight tracking-tight mb-6"
            >
              Discover the Best{" "}
              <span className="relative inline-block">
                <span className="bg-gradient-to-r from-emerald-500 via-sky-500 to-indigo-600 bg-clip-text text-transparent">
                  AI Tools
                </span>
                <svg className="absolute -bottom-1 left-0 w-full" viewBox="0 0 200 8" fill="none">
                  <path d="M1 6 C 50 2, 150 2, 199 6" stroke="url(#grad)" strokeWidth="2.5" strokeLinecap="round"/>
                  <defs>
                    <linearGradient id="grad" x1="0" y1="0" x2="200" y2="0" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stopColor="#10B981"/>
                      <stop offset="50%" stopColor="#0EA5E9"/>
                      <stop offset="100%" stopColor="#6366F1"/>
                    </linearGradient>
                  </defs>
                </svg>
              </span>{" "}
              to{" "}
              <span className="bg-gradient-to-r from-indigo-600 to-pink-600 bg-clip-text text-transparent">
                Boost Productivity
              </span>{" "}
              🚀
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-gray-500 mb-8 leading-relaxed max-w-xl"
            >
              Explore curated AI tools for{" "}
              <span className="font-medium text-gray-700">writing</span>,{" "}
              <span className="font-medium text-gray-700">coding</span>,{" "}
              <span className="font-medium text-gray-700">design</span>,{" "}
              <span className="font-medium text-gray-700">marketing</span>, and{" "}
              <span className="font-medium text-gray-700">automation</span>.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-3 mb-8"
            >
              <Link
                href="/tools"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-semibold text-white bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-xl shadow-lg shadow-emerald-200 hover:shadow-emerald-300 hover:from-emerald-600 hover:to-emerald-700 transition-all"
              >
                <Zap className="w-5 h-5" />
                Explore Tools
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/submit"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-semibold text-gray-700 bg-white border border-gray-200 rounded-xl hover:border-gray-300 hover:bg-gray-50 transition-all"
              >
                Submit a Tool
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex items-center gap-6 text-sm text-gray-400"
            >
              <div className="flex items-center gap-2">
                <div className="flex -space-x-1.5">
                  {["🤖", "🎨", "💻", "✨"].map((emoji, i) => (
                    <div key={i} className="w-7 h-7 rounded-full bg-gray-100 border-2 border-white flex items-center justify-center text-xs">
                      {emoji}
                    </div>
                  ))}
                </div>
                <span><strong className="text-gray-700">100+</strong> tools curated</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span><strong className="text-gray-700">4.8</strong> avg rating</span>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative"
          >
            <div className="relative bg-gradient-to-br from-gray-50 to-white rounded-3xl border border-gray-100 shadow-2xl shadow-gray-100 p-6 overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(16,185,129,0.06)_0%,_transparent_60%)]" />
              
              <div className="flex items-center gap-2 mb-5">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-yellow-400" />
                  <div className="w-3 h-3 rounded-full bg-green-400" />
                </div>
                <div className="flex-1 bg-white rounded-lg border border-gray-200 px-3 py-1.5 flex items-center gap-2">
                  <Search className="w-3.5 h-3.5 text-gray-400" />
                  <span className="text-xs text-gray-400">Search AI tools...</span>
                </div>
              </div>

              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Featured Tools</p>
              <div className="grid grid-cols-2 gap-3">
                {featured.map((tool, i) => (
                  <motion.div
                    key={tool.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }}
                    className="bg-white rounded-xl border border-gray-100 p-3.5 hover:border-emerald-200 hover:shadow-md transition-all group cursor-pointer"
                  >
                    <div className="text-2xl mb-2">{tool.icon}</div>
                    <p className="text-sm font-semibold text-gray-800 group-hover:text-emerald-700 transition-colors">{tool.name}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{tool.category}</p>
                    <div className="flex items-center gap-1 mt-2">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span className="text-xs font-medium text-gray-600">{tool.rating}</span>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-4 p-3 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center shrink-0">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-emerald-800">🔥 Trending This Week</p>
                  <p className="text-xs text-emerald-600 truncate">ChatGPT, Perplexity AI, Jasper...</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
