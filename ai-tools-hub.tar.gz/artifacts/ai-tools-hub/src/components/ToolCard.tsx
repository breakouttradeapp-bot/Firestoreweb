import { motion } from "framer-motion";
import { Star, ExternalLink, TrendingUp, Sparkles } from "lucide-react";
import type { Tool } from "@/data/tools";

const colorMap: Record<string, { bg: string; text: string; badge: string }> = {
  emerald: { bg: "bg-emerald-50", text: "text-emerald-700", badge: "bg-emerald-100 text-emerald-700" },
  indigo: { bg: "bg-indigo-50", text: "text-indigo-700", badge: "bg-indigo-100 text-indigo-700" },
  orange: { bg: "bg-orange-50", text: "text-orange-700", badge: "bg-orange-100 text-orange-700" },
  pink: { bg: "bg-pink-50", text: "text-pink-700", badge: "bg-pink-100 text-pink-700" },
  sky: { bg: "bg-sky-50", text: "text-sky-700", badge: "bg-sky-100 text-sky-700" },
};

const categoryColors: Record<string, string> = {
  Writing: "bg-emerald-100 text-emerald-700",
  Coding: "bg-sky-100 text-sky-700",
  Design: "bg-indigo-100 text-indigo-700",
  Marketing: "bg-orange-100 text-orange-700",
  Video: "bg-pink-100 text-pink-700",
  Productivity: "bg-emerald-100 text-emerald-700",
  Research: "bg-sky-100 text-sky-700",
  Automation: "bg-indigo-100 text-indigo-700",
};

type Props = {
  tool: Tool;
  index?: number;
};

export default function ToolCard({ tool, index = 0 }: Props) {
  const colors = colorMap[tool.color] || colorMap.emerald;
  const categoryColor = categoryColors[tool.category] || "bg-gray-100 text-gray-700";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.07 }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className="group bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-gray-100 transition-all duration-300 overflow-hidden flex flex-col"
    >
      <div className={`p-5 ${colors.bg}`}>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="text-3xl">{tool.icon}</div>
            <div>
              <h3 className="font-semibold text-gray-900 group-hover:text-gray-700 transition-colors">
                {tool.name}
              </h3>
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full mt-1 inline-block ${categoryColor}`}>
                {tool.category}
              </span>
            </div>
          </div>
          <div className="flex gap-1.5">
            {tool.isTrending && (
              <span className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full bg-orange-100 text-orange-700">
                <TrendingUp className="w-3 h-3" />
                Hot
              </span>
            )}
            {tool.isNew && (
              <span className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full bg-indigo-100 text-indigo-700">
                <Sparkles className="w-3 h-3" />
                New
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="p-5 flex flex-col flex-1">
        <p className="text-sm text-gray-600 leading-relaxed mb-4 flex-1">{tool.description}</p>

        <div className="flex flex-wrap gap-1.5 mb-4">
          {tool.tags.slice(0, 3).map((tag) => (
            <span
              key={tag}
              className="text-xs px-2.5 py-1 rounded-full bg-gray-50 border border-gray-100 text-gray-600 hover:border-gray-200 transition-colors"
            >
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-gray-50">
          <div className="flex items-center gap-1.5">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-3.5 h-3.5 ${
                    star <= Math.round(tool.rating) ? "text-amber-400 fill-amber-400" : "text-gray-200 fill-gray-200"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm font-medium text-gray-700">{tool.rating}</span>
            <span className="text-xs text-gray-400">({tool.reviews.toLocaleString()})</span>
          </div>

          <a
            href={tool.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg ${colors.bg} ${colors.text} hover:opacity-80 transition-opacity`}
          >
            Visit <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </motion.div>
  );
}
