import { motion } from "framer-motion";

type Props = {
  badge?: string;
  badgeColor?: "emerald" | "indigo" | "orange" | "pink" | "sky";
  title: string;
  subtitle?: string;
  action?: { label: string; href: string };
};

const badgeColors = {
  emerald: "bg-emerald-50 text-emerald-700 border-emerald-100",
  indigo: "bg-indigo-50 text-indigo-700 border-indigo-100",
  orange: "bg-orange-50 text-orange-700 border-orange-100",
  pink: "bg-pink-50 text-pink-700 border-pink-100",
  sky: "bg-sky-50 text-sky-700 border-sky-100",
};

export default function SectionHeader({ badge, badgeColor = "emerald", title, subtitle, action }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8"
    >
      <div>
        {badge && (
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full border mb-3 ${badgeColors[badgeColor]}`}>
            {badge}
          </span>
        )}
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">{title}</h2>
        {subtitle && <p className="mt-2 text-gray-500 max-w-2xl">{subtitle}</p>}
      </div>
      {action && (
        <a
          href={action.href}
          className="shrink-0 text-sm font-medium text-emerald-600 hover:text-emerald-700 flex items-center gap-1 hover:gap-2 transition-all"
        >
          {action.label} →
        </a>
      )}
    </motion.div>
  );
}
