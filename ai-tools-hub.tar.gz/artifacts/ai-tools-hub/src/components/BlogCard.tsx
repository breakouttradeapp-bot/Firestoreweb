import { motion } from "framer-motion";
import { Clock, ArrowRight, User } from "lucide-react";
import type { BlogPost } from "@/data/blog";

const colorMap: Record<string, { bg: string; text: string }> = {
  emerald: { bg: "bg-emerald-50", text: "text-emerald-700" },
  indigo: { bg: "bg-indigo-50", text: "text-indigo-700" },
  orange: { bg: "bg-orange-50", text: "text-orange-700" },
  pink: { bg: "bg-pink-50", text: "text-pink-700" },
  sky: { bg: "bg-sky-50", text: "text-sky-700" },
};

type Props = {
  post: BlogPost;
  index?: number;
};

export default function BlogCard({ post, index = 0 }: Props) {
  const colors = colorMap[post.color] || colorMap.emerald;

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.07 }}
      whileHover={{ y: -3, transition: { duration: 0.2 } }}
      className="group bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-gray-100 transition-all duration-300 overflow-hidden cursor-pointer"
    >
      <div className={`p-6 ${colors.bg}`}>
        <div className="flex items-center justify-between mb-3">
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${colors.bg} ${colors.text} border border-current border-opacity-20`}>
            {post.category}
          </span>
          <div className="flex items-center gap-1 text-xs text-gray-400">
            <Clock className="w-3 h-3" />
            {post.readTime}
          </div>
        </div>
        <div className="text-4xl">{post.emoji}</div>
      </div>

      <div className="p-6">
        <h3 className="font-semibold text-gray-900 leading-snug mb-2 group-hover:text-emerald-700 transition-colors line-clamp-2">
          {post.title}
        </h3>
        <p className="text-sm text-gray-500 leading-relaxed mb-4 line-clamp-2">{post.excerpt}</p>

        <div className="flex items-center justify-between pt-4 border-t border-gray-50">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-emerald-400 to-indigo-500 flex items-center justify-center">
              <User className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <p className="text-xs font-medium text-gray-700">{post.author}</p>
              <p className="text-xs text-gray-400">{post.date}</p>
            </div>
          </div>
          <span className="flex items-center gap-1 text-xs font-medium text-emerald-600 group-hover:gap-2 transition-all">
            Read more <ArrowRight className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>
    </motion.article>
  );
}
