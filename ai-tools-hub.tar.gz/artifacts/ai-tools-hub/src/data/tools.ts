export type Tool = {
  id: string;
  name: string;
  description: string;
  category: string;
  tags: string[];
  rating: number;
  reviews: number;
  url: string;
  isTrending?: boolean;
  isNew?: boolean;
  isFeatured?: boolean;
  icon: string;
  color: string;
};

export const tools: Tool[] = [
  {
    id: "1",
    name: "ChatGPT",
    description: "Advanced AI chatbot for writing, analysis, coding, and creative tasks powered by GPT-4.",
    category: "Writing",
    tags: ["Writing", "Coding", "Research"],
    rating: 4.9,
    reviews: 12450,
    url: "https://chat.openai.com",
    isTrending: true,
    isFeatured: true,
    icon: "🤖",
    color: "emerald",
  },
  {
    id: "2",
    name: "Midjourney",
    description: "AI image generation tool that creates stunning artwork from text prompts.",
    category: "Design",
    tags: ["Design", "Images", "Art"],
    rating: 4.8,
    reviews: 9800,
    url: "https://midjourney.com",
    isTrending: true,
    isFeatured: true,
    icon: "🎨",
    color: "indigo",
  },
  {
    id: "3",
    name: "GitHub Copilot",
    description: "AI pair programmer that suggests code completions and entire functions in real time.",
    category: "Coding",
    tags: ["Coding", "Development", "Automation"],
    rating: 4.7,
    reviews: 8200,
    url: "https://github.com/features/copilot",
    isTrending: true,
    isFeatured: true,
    icon: "💻",
    color: "sky",
  },
  {
    id: "4",
    name: "Claude",
    description: "Anthropic's AI assistant for thoughtful analysis, writing, and complex reasoning.",
    category: "Writing",
    tags: ["Writing", "Research", "Analysis"],
    rating: 4.8,
    reviews: 6700,
    url: "https://claude.ai",
    isNew: true,
    isFeatured: true,
    icon: "✨",
    color: "orange",
  },
  {
    id: "5",
    name: "Jasper",
    description: "AI writing assistant designed for marketing teams to create high-converting copy.",
    category: "Marketing",
    tags: ["Marketing", "Writing", "SEO"],
    rating: 4.6,
    reviews: 5400,
    url: "https://jasper.ai",
    isTrending: true,
    icon: "📝",
    color: "pink",
  },
  {
    id: "6",
    name: "Runway ML",
    description: "Creative AI tools for video editing, image generation, and visual storytelling.",
    category: "Video",
    tags: ["Video", "Design", "Creative"],
    rating: 4.5,
    reviews: 4100,
    url: "https://runwayml.com",
    isNew: true,
    icon: "🎬",
    color: "indigo",
  },
  {
    id: "7",
    name: "Notion AI",
    description: "AI-powered writing assistant built into Notion for notes, docs, and wikis.",
    category: "Productivity",
    tags: ["Productivity", "Writing", "Organization"],
    rating: 4.6,
    reviews: 7300,
    url: "https://notion.so",
    icon: "📋",
    color: "emerald",
  },
  {
    id: "8",
    name: "Grammarly",
    description: "AI writing tool that checks grammar, style, tone, and suggests improvements.",
    category: "Writing",
    tags: ["Writing", "Grammar", "Editing"],
    rating: 4.7,
    reviews: 15200,
    url: "https://grammarly.com",
    icon: "✅",
    color: "sky",
  },
  {
    id: "9",
    name: "Synthesia",
    description: "Create professional AI videos with realistic avatars from text scripts.",
    category: "Video",
    tags: ["Video", "Marketing", "Automation"],
    rating: 4.5,
    reviews: 3800,
    url: "https://synthesia.io",
    isNew: true,
    icon: "📹",
    color: "orange",
  },
  {
    id: "10",
    name: "Copy.ai",
    description: "AI copywriting tool for social media posts, ads, emails, and product descriptions.",
    category: "Marketing",
    tags: ["Marketing", "Writing", "Social Media"],
    rating: 4.4,
    reviews: 6100,
    url: "https://copy.ai",
    icon: "📣",
    color: "pink",
  },
  {
    id: "11",
    name: "Perplexity AI",
    description: "AI-powered search engine that answers questions with cited sources.",
    category: "Research",
    tags: ["Research", "Search", "Analysis"],
    rating: 4.6,
    reviews: 4900,
    url: "https://perplexity.ai",
    isNew: true,
    isTrending: true,
    icon: "🔍",
    color: "sky",
  },
  {
    id: "12",
    name: "Zapier AI",
    description: "AI-powered automation to connect apps and streamline workflows without code.",
    category: "Automation",
    tags: ["Automation", "Productivity", "Integration"],
    rating: 4.5,
    reviews: 5600,
    url: "https://zapier.com",
    icon: "⚡",
    color: "emerald",
  },
];

export const categories = ["All", "Writing", "Coding", "Design", "Marketing", "Video", "Productivity", "Research", "Automation"];

export const getFeaturedTools = () => tools.filter(t => t.isFeatured).slice(0, 4);
export const getTrendingTools = () => tools.filter(t => t.isTrending).slice(0, 6);
export const getNewTools = () => tools.filter(t => t.isNew).slice(0, 6);
export const getTopRatedTools = () => [...tools].sort((a, b) => b.rating - a.rating).slice(0, 6);
