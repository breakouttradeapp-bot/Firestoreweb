export type BlogPost = {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  author: string;
  slug: string;
  emoji: string;
  color: string;
};

export const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "Top 10 AI Writing Tools to Boost Your Content in 2025",
    excerpt: "Discover the best AI-powered writing assistants that can help you create compelling content faster than ever before.",
    category: "Writing",
    readTime: "5 min read",
    date: "Mar 20, 2025",
    author: "Sarah Chen",
    slug: "top-10-ai-writing-tools-2025",
    emoji: "✍️",
    color: "emerald",
  },
  {
    id: "2",
    title: "How AI Code Assistants Are Changing Software Development",
    excerpt: "From GitHub Copilot to Cursor AI, explore how artificial intelligence is transforming how developers write and review code.",
    category: "Coding",
    readTime: "7 min read",
    date: "Mar 18, 2025",
    author: "Marcus Johnson",
    slug: "ai-code-assistants-changing-development",
    emoji: "🖥️",
    color: "indigo",
  },
  {
    id: "3",
    title: "AI Image Generation: A Complete Beginner's Guide",
    excerpt: "Learn how to create stunning visuals using Midjourney, DALL·E, and Stable Diffusion with these practical tips.",
    category: "Design",
    readTime: "8 min read",
    date: "Mar 15, 2025",
    author: "Priya Sharma",
    slug: "ai-image-generation-beginners-guide",
    emoji: "🎨",
    color: "pink",
  },
  {
    id: "4",
    title: "Automating Your Marketing Workflow with AI Tools",
    excerpt: "Save hours every week by automating content creation, scheduling, and analytics with today's best AI marketing tools.",
    category: "Marketing",
    readTime: "6 min read",
    date: "Mar 12, 2025",
    author: "Alex Rivera",
    slug: "automating-marketing-workflow-ai",
    emoji: "📊",
    color: "orange",
  },
  {
    id: "5",
    title: "The Best AI Tools for Productivity in Remote Work",
    excerpt: "Stay organized and focused with AI-powered productivity apps designed for distributed teams and remote workers.",
    category: "Productivity",
    readTime: "5 min read",
    date: "Mar 10, 2025",
    author: "Emma Wilson",
    slug: "best-ai-tools-productivity-remote-work",
    emoji: "🚀",
    color: "sky",
  },
  {
    id: "6",
    title: "AI Video Creation Tools That Are Taking Over Social Media",
    excerpt: "From talking avatars to cinematic footage, these AI video tools are making professional production accessible to everyone.",
    category: "Video",
    readTime: "6 min read",
    date: "Mar 8, 2025",
    author: "David Kim",
    slug: "ai-video-creation-tools-social-media",
    emoji: "🎬",
    color: "indigo",
  },
];
