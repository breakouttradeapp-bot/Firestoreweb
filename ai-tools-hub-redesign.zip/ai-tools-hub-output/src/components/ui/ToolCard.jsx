// src/components/ui/ToolCard.jsx
import { Link } from 'react-router-dom'
import { Eye, ArrowRight, Star } from 'lucide-react'

const CATEGORY_ACCENTS = {
  'Writing AI':   { bg: 'bg-indigo-50',  text: 'text-indigo-600',  border: 'border-indigo-200',  dot: 'bg-indigo-400' },
  'Image AI':     { bg: 'bg-pink-50',    text: 'text-pink-600',    border: 'border-pink-200',    dot: 'bg-pink-400' },
  'Video AI':     { bg: 'bg-orange-50',  text: 'text-orange-600',  border: 'border-orange-200',  dot: 'bg-orange-400' },
  'Coding AI':    { bg: 'bg-sky-50',     text: 'text-sky-600',     border: 'border-sky-200',     dot: 'bg-sky-400' },
  'Marketing AI': { bg: 'bg-emerald-50', text: 'text-emerald-600', border: 'border-emerald-200', dot: 'bg-emerald-400' },
}

const DEFAULT_ACCENT = { bg: 'bg-gray-50', text: 'text-gray-600', border: 'border-gray-200', dot: 'bg-gray-400' }

export default function ToolCard({ tool, size = 'md' }) {
  const accent = CATEGORY_ACCENTS[tool.category] || DEFAULT_ACCENT

  const pricingConfig = {
    Free:     { class: 'tag-free',     label: 'Free' },
    Paid:     { class: 'tag-paid',     label: 'Paid' },
    Freemium: { class: 'tag-freemium', label: 'Freemium' },
  }[tool.pricing] || { class: 'tag-freemium', label: tool.pricing }

  if (size === 'sm') {
    return (
      <Link
        to={`/tools/${tool.slug}`}
        className="tool-card flex items-center gap-4 p-4 group"
      >
        <div className={`w-12 h-12 rounded-xl ${accent.bg} flex items-center justify-center text-2xl flex-shrink-0 border ${accent.border}`}>
          {tool.logo}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-display font-semibold text-gray-900 text-sm truncate group-hover:text-primary-600 transition-colors">
            {tool.name}
          </h3>
          <p className="text-gray-400 text-xs truncate mt-0.5">{tool.description.slice(0, 60)}...</p>
        </div>
        <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-primary-500 group-hover:translate-x-0.5 transition-all flex-shrink-0" />
      </Link>
    )
  }

  return (
    <Link
      to={`/tools/${tool.slug}`}
      className="tool-card flex flex-col p-5 group relative overflow-hidden"
    >
      {/* Subtle top accent line */}
      <div className={`absolute top-0 left-0 right-0 h-0.5 ${accent.bg} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} 
           style={{ background: `linear-gradient(90deg, transparent, var(--accent-color, #6366f1), transparent)` }} />

      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className={`w-14 h-14 rounded-2xl ${accent.bg} border ${accent.border} flex items-center justify-center text-3xl shadow-sm group-hover:scale-105 transition-transform duration-300`}>
          {tool.logo}
        </div>
        <div className="flex items-center gap-1.5">
          <span className={pricingConfig.class}>{pricingConfig.label}</span>
        </div>
      </div>

      {/* Name & Description */}
      <h3 className="font-display font-bold text-gray-900 text-base mb-1.5 group-hover:text-primary-600 transition-colors leading-snug">
        {tool.name}
      </h3>
      <p className="text-gray-500 text-sm leading-relaxed flex-1 line-clamp-2">
        {tool.description}
      </p>

      {/* Tags */}
      <div className="flex flex-wrap gap-1.5 mt-3">
        <span className={`inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-full font-medium border ${accent.bg} ${accent.text} ${accent.border}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${accent.dot}`} />
          {tool.category}
        </span>
        {tool.tags?.slice(0, 2).map(tag => (
          <span
            key={tag}
            className="bg-gray-50 text-gray-500 text-xs px-2.5 py-0.5 rounded-full border border-gray-200 font-medium"
          >
            {tag}
          </span>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-50">
        <div className="flex items-center gap-1.5 text-gray-400 text-xs">
          <Eye className="w-3.5 h-3.5" />
          <span>{tool.views?.toLocaleString() ?? 0} views</span>
        </div>
        <div className="flex items-center gap-1 text-primary-600 text-xs font-semibold group-hover:gap-2 transition-all duration-200">
          <span>View tool</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </div>
      </div>
    </Link>
  )
}
