// src/components/ui/Skeleton.jsx

export function SkeletonToolCard() {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl shadow-card p-5 animate-pulse">
      <div className="flex items-start justify-between mb-4">
        <div className="w-14 h-14 rounded-2xl skeleton" />
        <div className="w-16 h-5 rounded-full skeleton" />
      </div>
      <div className="w-3/4 h-5 rounded-lg skeleton mb-2" />
      <div className="space-y-1.5 mb-3">
        <div className="w-full h-3.5 rounded skeleton" />
        <div className="w-5/6 h-3.5 rounded skeleton" />
      </div>
      <div className="flex gap-1.5 mb-4">
        <div className="w-20 h-5 rounded-full skeleton" />
        <div className="w-14 h-5 rounded-full skeleton" />
      </div>
      <div className="pt-4 border-t border-gray-50 flex justify-between">
        <div className="w-20 h-3.5 rounded skeleton" />
        <div className="w-16 h-3.5 rounded skeleton" />
      </div>
    </div>
  )
}

export function SkeletonBlogCard() {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl shadow-card animate-pulse overflow-hidden">
      <div className="h-40 skeleton rounded-t-2xl" />
      <div className="p-5 space-y-3">
        <div className="flex gap-2">
          <div className="w-20 h-5 rounded-full skeleton" />
          <div className="w-16 h-5 rounded-full skeleton" />
        </div>
        <div className="w-full h-5 rounded skeleton" />
        <div className="w-4/5 h-5 rounded skeleton" />
        <div className="space-y-1.5">
          <div className="w-full h-3.5 rounded skeleton" />
          <div className="w-full h-3.5 rounded skeleton" />
          <div className="w-3/4 h-3.5 rounded skeleton" />
        </div>
      </div>
    </div>
  )
}

export function SkeletonText({ lines = 3, className = '' }) {
  return (
    <div className={`space-y-2 ${className}`}>
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className="h-4 rounded skeleton"
          style={{ width: i === lines - 1 ? '60%' : '100%' }}
        />
      ))}
    </div>
  )
}
