// src/components/ui/BlogCard.jsx
import { Link } from 'react-router-dom'
import { Clock, ArrowRight } from 'lucide-react'

const CATEGORY_STYLES = {
  Reviews:     'text-sky-600 bg-sky-50 border-sky-200',
  Guides:      'text-emerald-600 bg-emerald-50 border-emerald-200',
  Comparisons: 'text-indigo-600 bg-indigo-50 border-indigo-200',
  Business:    'text-amber-600 bg-amber-50 border-amber-200',
  Education:   'text-blue-600 bg-blue-50 border-blue-200',
  Trends:      'text-pink-600 bg-pink-50 border-pink-200',
}

const COVER_GRADIENTS = {
  Reviews:     'from-sky-50 to-blue-100',
  Guides:      'from-emerald-50 to-teal-100',
  Comparisons: 'from-indigo-50 to-purple-100',
  Business:    'from-amber-50 to-orange-100',
  Education:   'from-blue-50 to-indigo-100',
  Trends:      'from-pink-50 to-rose-100',
}

export default function BlogCard({ post, featured = false }) {
  const catStyle = CATEGORY_STYLES[post.category] || 'text-gray-600 bg-gray-50 border-gray-200'
  const coverGrad = COVER_GRADIENTS[post.category] || 'from-gray-50 to-gray-100'

  if (featured) {
    return (
      <Link
        to={`/blog/${post.slug}`}
        className="tool-card group flex flex-col md:flex-row gap-6 p-6 md:p-8"
      >
        <div className={`md:w-48 md:h-48 w-full h-40 rounded-2xl bg-gradient-to-br ${coverGrad} border border-gray-100 flex items-center justify-center text-6xl flex-shrink-0`}>
          {post.coverEmoji}
        </div>
        <div className="flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${catStyle}`}>
              {post.category}
            </span>
            <span className="text-gray-400 text-xs flex items-center gap-1">
              <Clock className="w-3 h-3" />{post.readTime}
            </span>
          </div>
          <h2 className="font-display font-bold text-gray-900 text-xl md:text-2xl mb-2 group-hover:text-primary-600 transition-colors leading-snug">
            {post.title}
          </h2>
          <p className="text-gray-500 text-sm leading-relaxed flex-1 line-clamp-3">{post.excerpt}</p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-gray-400 text-xs">{post.author} · {post.publishedAt}</span>
            <div className="flex items-center gap-1 text-primary-600 text-sm font-semibold group-hover:gap-2 transition-all">
              Read more <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </Link>
    )
  }

  return (
    <Link
      to={`/blog/${post.slug}`}
      className="tool-card flex flex-col group overflow-hidden"
    >
      <div className={`h-40 bg-gradient-to-br ${coverGrad} flex items-center justify-center text-5xl border-b border-gray-100`}>
        {post.coverEmoji}
      </div>
      <div className="p-5 flex flex-col flex-1">
        <div className="flex items-center gap-2 mb-3">
          <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${catStyle}`}>
            {post.category}
          </span>
          <span className="text-gray-400 text-xs flex items-center gap-1">
            <Clock className="w-3 h-3" />{post.readTime}
          </span>
        </div>
        <h3 className="font-display font-bold text-gray-900 text-base mb-2 group-hover:text-primary-600 transition-colors leading-snug line-clamp-2">
          {post.title}
        </h3>
        <p className="text-gray-500 text-sm leading-relaxed flex-1 line-clamp-3">{post.excerpt}</p>
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-50">
          <span className="text-gray-400 text-xs truncate">{post.author}</span>
          <div className="flex items-center gap-1 text-primary-600 text-xs font-semibold group-hover:gap-2 transition-all whitespace-nowrap">
            Read <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>
    </Link>
  )
}
