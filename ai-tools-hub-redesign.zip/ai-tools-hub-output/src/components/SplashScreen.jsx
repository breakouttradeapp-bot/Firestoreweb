// src/components/SplashScreen.jsx
import { useEffect, useState } from 'react'
import { Zap } from 'lucide-react'

export default function SplashScreen({ onComplete }) {
  const [phase, setPhase] = useState(0)

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 200)
    const t2 = setTimeout(() => setPhase(2), 800)
    const t3 = setTimeout(() => setPhase(3), 1700)
    const t4 = setTimeout(() => onComplete(), 2200)
    return () => [t1, t2, t3, t4].forEach(clearTimeout)
  }, [onComplete])

  return (
    <div
      className={`fixed inset-0 z-[999] flex flex-col items-center justify-center bg-white transition-opacity duration-500 ${
        phase === 3 ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Soft background blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gradient-to-br from-indigo-100/60 to-sky-100/40 blur-3xl animate-pulse-slow" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full bg-gradient-to-br from-pink-100/40 to-purple-100/20 blur-2xl animate-pulse-slow" style={{ animationDelay: '1s' }} />
      </div>

      {/* Logo + wordmark */}
      <div
        className={`relative z-10 flex flex-col items-center gap-6 transition-all duration-700 ${
          phase >= 1 ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
        }`}
      >
        {/* Icon */}
        <div className="relative">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-primary-600 to-indigo-500 flex items-center justify-center shadow-btn">
            <Zap className="w-12 h-12 text-white" fill="white" />
          </div>
          <div className="absolute inset-0 rounded-3xl border-2 border-primary-300/40 animate-spin-slow" />
          <div className="absolute -inset-2 rounded-[28px] border border-indigo-200/60 animate-spin-slow" style={{ animationDirection: 'reverse', animationDuration: '6s' }} />
        </div>

        {/* Brand name */}
        <div
          className={`text-center transition-all duration-500 delay-200 ${
            phase >= 1 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <h1 className="font-display text-4xl font-bold text-gray-900 tracking-tight">
            AI Tools <span className="neon-text">Hub</span>
          </h1>
          <p className="text-gray-400 mt-2 font-body text-sm">Discover the future of AI</p>
        </div>

        {/* Loading bar */}
        <div
          className={`mt-4 transition-all duration-500 delay-300 ${
            phase >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
          }`}
        >
          <div className="w-48 h-1.5 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary-600 to-sky-400 rounded-full transition-all duration-[1200ms] ease-out"
              style={{ width: phase >= 2 ? '100%' : '0%' }}
            />
          </div>
          <p className="text-gray-400 text-xs mt-3 text-center font-body animate-pulse">
            Loading AI Tools...
          </p>
        </div>
      </div>
    </div>
  )
}
