// src/components/layout/Footer.jsx
import { Link } from 'react-router-dom'
import { Zap, Twitter, Github, Rss, ArrowRight } from 'lucide-react'

const FOOTER_LINKS = {
  'Directory': [
    { label: 'All Tools', to: '/tools' },
    { label: 'Writing AI', to: '/tools?category=Writing+AI' },
    { label: 'Image AI', to: '/tools?category=Image+AI' },
    { label: 'Video AI', to: '/tools?category=Video+AI' },
    { label: 'Coding AI', to: '/tools?category=Coding+AI' },
    { label: 'Marketing AI', to: '/tools?category=Marketing+AI' },
  ],
  'Resources': [
    { label: 'AI Prompts', to: '/prompts' },
    { label: 'Blog', to: '/blog' },
    { label: 'ChatGPT Prompts', to: '/prompts?category=ChatGPT' },
    { label: 'Resume Prompts', to: '/prompts?category=Resume' },
    { label: 'Business Prompts', to: '/prompts?category=Business' },
  ],
  'Company': [
    { label: 'About Us', to: '/about' },
    { label: 'Contact Us', to: '/contact' },
    { label: 'Privacy Policy', to: '/privacy' },
    { label: 'Terms & Conditions', to: '/terms' },
  ],
}

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">

        {/* Top section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mb-12">

          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2.5 mb-4 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-600 to-indigo-500 flex items-center justify-center shadow-btn transition-all group-hover:shadow-btn-hover group-hover:scale-105">
                <Zap className="w-4.5 h-4.5 text-white" fill="white" />
              </div>
              <span className="font-display font-bold text-lg text-gray-900">
                AI Tools <span className="text-primary-600">Hub</span>
              </span>
            </Link>
            <p className="text-gray-500 text-sm leading-relaxed mb-5">
              Your ultimate directory for discovering the best AI tools, prompts, and resources. Updated daily.
            </p>
            <div className="flex items-center gap-2">
              {[
                { href: 'https://twitter.com', Icon: Twitter, label: 'Twitter' },
                { href: 'https://github.com', Icon: Github, label: 'GitHub' },
                { href: '/rss.xml', Icon: Rss, label: 'RSS' },
              ].map(({ href, Icon, label }) => (
                <a
                  key={label}
                  href={href}
                  target={href.startsWith('http') ? '_blank' : undefined}
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="w-9 h-9 rounded-lg bg-white border border-gray-200 hover:border-primary-300 hover:bg-primary-50 flex items-center justify-center text-gray-500 hover:text-primary-600 transition-all duration-200 shadow-sm"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(FOOTER_LINKS).map(([section, links]) => (
            <div key={section}>
              <h3 className="font-display font-bold text-gray-900 text-sm mb-4">{section}</h3>
              <ul className="space-y-2.5">
                {links.map(({ label, to }) => (
                  <li key={to}>
                    <Link
                      to={to}
                      className="text-gray-500 hover:text-primary-600 text-sm transition-colors duration-200 font-medium"
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter */}
        <div className="border-t border-gray-200 pt-8 mb-8">
          <div className="max-w-md">
            <h3 className="font-display font-bold text-gray-900 mb-1">Stay Updated</h3>
            <p className="text-gray-500 text-sm mb-4">Get the latest AI tools and news in your inbox weekly.</p>
            <form
              onSubmit={e => e.preventDefault()}
              className="flex gap-2"
            >
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 bg-white border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:border-primary-400 focus:ring-2 focus:ring-primary-100 transition-all shadow-sm"
              />
              <button
                type="submit"
                className="btn-primary py-2.5 px-5 text-sm"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-gray-200 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} AI Tools Hub. All rights reserved.
          </p>
          <p className="text-gray-400 text-sm">
            Built with ❤️ for the AI community · Updated daily
          </p>
        </div>
      </div>
    </footer>
  )
}
