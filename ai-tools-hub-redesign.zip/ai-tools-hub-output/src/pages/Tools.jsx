// src/pages/Tools.jsx
import { useState, useEffect, useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Search, SlidersHorizontal, X, Grid3X3, List, Sparkles } from 'lucide-react'
import { useApp } from '../context/AppContext'
import ToolCard from '../components/ui/ToolCard'
import SEOHead from '../components/ui/SEOHead'
import { AdBannerTop, AdBannerInContent } from '../components/ads/AdBanner'
import { CATEGORIES } from '../data/tools'

const PRICING_OPTIONS = ['All', 'Free', 'Freemium', 'Paid']

const PRICING_COLORS = {
  All:      'bg-gray-100 text-gray-600 border-gray-200 hover:border-gray-400',
  Free:     'bg-emerald-50 text-emerald-600 border-emerald-200 hover:border-emerald-400',
  Freemium: 'bg-indigo-50 text-indigo-600 border-indigo-200 hover:border-indigo-400',
  Paid:     'bg-amber-50 text-amber-600 border-amber-200 hover:border-amber-400',
}

export default function Tools() {
  const { tools } = useApp()
  const [searchParams, setSearchParams] = useSearchParams()
  const [searchInput, setSearchInput] = useState(searchParams.get('q') || '')
  const [searchFocused, setSearchFocused] = useState(false)
  const [activeCategory, setActiveCategory] = useState(searchParams.get('category') || 'All')
  const [activePricing, setActivePricing] = useState('All')
  const [showFilters, setShowFilters] = useState(false)
  const [viewMode, setViewMode] = useState('grid')

  useEffect(() => {
    const q = searchParams.get('q')
    const cat = searchParams.get('category')
    if (q) setSearchInput(q)
    if (cat) setActiveCategory(cat)
  }, [searchParams])

  const filtered = useMemo(() => {
    return tools.filter(tool => {
      const matchesSearch = !searchInput.trim() ||
        tool.name.toLowerCase().includes(searchInput.toLowerCase()) ||
        tool.description.toLowerCase().includes(searchInput.toLowerCase()) ||
        tool.tags?.some(t => t.toLowerCase().includes(searchInput.toLowerCase()))
      const matchesCategory = activeCategory === 'All' || tool.category === activeCategory
      const matchesPricing = activePricing === 'All' || tool.pricing === activePricing
      return matchesSearch && matchesCategory && matchesPricing
    })
  }, [tools, searchInput, activeCategory, activePricing])

  const handleCategoryChange = (cat) => {
    setActiveCategory(cat)
    const params = new URLSearchParams(searchParams)
    if (cat === 'All') params.delete('category')
    else params.set('category', cat)
    setSearchParams(params)
  }

  const handleSearch = (val) => {
    setSearchInput(val)
    const params = new URLSearchParams(searchParams)
    if (val.trim()) params.set('q', val.trim())
    else params.delete('q')
    setSearchParams(params)
  }

  const clearFilters = () => {
    setSearchInput('')
    setActiveCategory('All')
    setActivePricing('All')
    setSearchParams({})
  }

  const hasActiveFilters = searchInput || activeCategory !== 'All' || activePricing !== 'All'

  return (
    <>
      <SEOHead
        title="AI Tools Directory — 500+ AI Tools"
        description="Browse 500+ AI tools organized by category. Find the best AI tools for writing, image generation, video creation, coding, and marketing."
        canonical="/tools"
      />

      {/* Header */}
      <div className="bg-gradient-to-b from-gray-50 to-white border-b border-gray-100 pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full bg-indigo-50 text-indigo-600 border border-indigo-200">
              <Sparkles className="w-3 h-3" /> AI Directory
            </span>
          </div>
          <h1 className="font-display font-extrabold text-4xl sm:text-5xl text-gray-900 mb-3">
            AI Tools <span className="neon-text">Directory</span>
          </h1>
          <p className="text-gray-500 text-lg max-w-2xl">
            Browse {tools.length}+ AI tools across every category. Filtered, ranked, and reviewed.
          </p>

          {/* Search bar */}
          <div className="mt-6 flex gap-3 max-w-2xl">
            <div className="relative flex-1">
              <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 pointer-events-none transition-colors ${searchFocused ? 'text-primary-500' : 'text-gray-400'}`} />
              <input
                type="text"
                value={searchInput}
                onChange={e => handleSearch(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setSearchFocused(false)}
                placeholder="Search tools by name, category, or feature..."
                className={`w-full bg-white border rounded-xl pl-12 pr-10 py-3.5 text-base text-gray-900 placeholder-gray-400 focus:outline-none shadow-card transition-all duration-200 ${
                  searchFocused
                    ? 'border-primary-400 ring-2 ring-primary-100'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              />
              {searchInput && (
                <button
                  onClick={() => handleSearch('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`btn-secondary flex items-center gap-2 ${showFilters ? 'border-primary-300 text-primary-600 bg-primary-50' : ''}`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              Filters
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AdBannerTop />

        {/* Filters panel */}
        {showFilters && (
          <div className="bg-white border border-gray-100 rounded-2xl shadow-card p-5 mb-6">
            <div className="flex flex-col sm:flex-row gap-6">
              <div className="flex-1">
                <p className="text-gray-500 text-xs font-semibold mb-2 uppercase tracking-wide">Pricing</p>
                <div className="flex flex-wrap gap-2">
                  {PRICING_OPTIONS.map(p => (
                    <button
                      key={p}
                      onClick={() => setActivePricing(p)}
                      className={`px-3.5 py-1.5 rounded-lg text-sm font-medium border transition-all ${
                        activePricing === p
                          ? `${PRICING_COLORS[p]} ring-2 ring-offset-1 ring-primary-200`
                          : 'bg-gray-50 text-gray-500 border-gray-200 hover:border-gray-400 hover:text-gray-700'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
              {hasActiveFilters && (
                <button
                  onClick={clearFilters}
                  className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-900 border border-gray-200 hover:border-gray-400 px-4 py-2 rounded-lg transition-colors self-end font-medium"
                >
                  <X className="w-3.5 h-3.5" /> Clear All
                </button>
              )}
            </div>
          </div>
        )}

        {/* Category pills */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto no-scrollbar pb-1">
          {['All', ...CATEGORIES.map(c => c.name)].map(cat => (
            <button
              key={cat}
              onClick={() => handleCategoryChange(cat)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap border transition-all duration-200 ${
                activeCategory === cat
                  ? 'bg-primary-50 text-primary-700 border-primary-300 font-semibold shadow-sm'
                  : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300 hover:text-gray-700 shadow-sm'
              }`}
            >
              {cat === 'All' ? `All Tools (${tools.length})` : cat}
            </button>
          ))}
        </div>

        {/* Results header */}
        <div className="flex items-center justify-between mb-5">
          <p className="text-gray-500 text-sm">
            {filtered.length === 0 ? 'No tools found' : `${filtered.length} tool${filtered.length !== 1 ? 's' : ''} found`}
            {searchInput && <span className="text-gray-400"> for "<span className="text-gray-600 font-medium">{searchInput}</span>"</span>}
          </p>
          <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-lg">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-white text-primary-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <Grid3X3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-md transition-colors ${viewMode === 'list' ? 'bg-white text-primary-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tool grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-24 bg-white border border-gray-100 rounded-2xl shadow-card">
            <div className="text-5xl mb-4">🔍</div>
            <h3 className="font-display font-bold text-xl text-gray-900 mb-2">No tools found</h3>
            <p className="text-gray-500 mb-6">Try adjusting your search or filters</p>
            <button onClick={clearFilters} className="btn-primary">Clear Filters</button>
          </div>
        ) : (
          <div className={
            viewMode === 'grid'
              ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5'
              : 'flex flex-col gap-3'
          }>
            {filtered.map((tool, idx) => (
              <div key={tool.slug}>
                <ToolCard tool={tool} size={viewMode === 'list' ? 'sm' : 'md'} />
                {idx === 5 && (
                  <div className={viewMode === 'grid' ? 'hidden' : ''}>
                    <AdBannerInContent className="my-4" />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {filtered.length > 6 && <AdBannerInContent className="mt-8" />}
      </div>
    </>
  )
}
