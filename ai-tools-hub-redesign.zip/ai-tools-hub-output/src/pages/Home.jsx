// src/pages/Home.jsx
import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search, Zap, TrendingUp, Newspaper, ArrowRight, Star,
  Users, BookOpen, Cpu, Flame, Sparkles, ChevronRight,
  PenLine, Image, Video, Code2, Megaphone, Bot
} from 'lucide-react'
import { useApp } from '../context/AppContext'
import ToolCard from '../components/ui/ToolCard'
import BlogCard from '../components/ui/BlogCard'
import SEOHead from '../components/ui/SEOHead'
import { AdBannerTop, AdBannerInContent } from '../components/ads/AdBanner'
import { CATEGORIES } from '../data/tools'

// ── Constants ──────────────────────────────────────────────────────────────

const STATS = [
  { icon: Cpu,      label: 'AI Tools',         value: '500+',   color: 'text-indigo-600', bg: 'bg-indigo-50'  },
  { icon: Users,    label: 'Monthly Visitors',  value: '120K+',  color: 'text-sky-600',    bg: 'bg-sky-50'     },
  { icon: BookOpen, label: 'Prompts',           value: '200+',   color: 'text-emerald-600',bg: 'bg-emerald-50' },
  { icon: Star,     label: 'Reviews',           value: '1,000+', color: 'text-amber-600',  bg: 'bg-amber-50'   },
]

const CATEGORY_CONFIG = [
  { key: 'Writing AI',   icon: PenLine,   emoji: '✍️', color: 'text-indigo-600', bg: 'bg-indigo-50',  border: 'border-indigo-200', gradient: 'from-indigo-50 to-indigo-100' },
  { key: 'Image AI',     icon: Image,     emoji: '🎨', color: 'text-pink-600',   bg: 'bg-pink-50',    border: 'border-pink-200',   gradient: 'from-pink-50 to-pink-100'    },
  { key: 'Video AI',     icon: Video,     emoji: '🎬', color: 'text-orange-600', bg: 'bg-orange-50',  border: 'border-orange-200', gradient: 'from-orange-50 to-orange-100' },
  { key: 'Coding AI',    icon: Code2,     emoji: '💻', color: 'text-sky-600',    bg: 'bg-sky-50',     border: 'border-sky-200',    gradient: 'from-sky-50 to-sky-100'      },
  { key: 'Marketing AI', icon: Megaphone, emoji: '📢', color: 'text-emerald-600',bg: 'bg-emerald-50', border: 'border-emerald-200',gradient: 'from-emerald-50 to-emerald-100'},
]

const FLOATING_BADGES = [
  { icon: '🔥', label: 'Trending',   color: 'bg-orange-50 text-orange-600 border-orange-200', delay: 0    },
  { icon: '⭐', label: 'Top Rated',  color: 'bg-amber-50 text-amber-600 border-amber-200',    delay: 0.15 },
  { icon: '🆕', label: 'New Tools',  color: 'bg-emerald-50 text-emerald-600 border-emerald-200', delay: 0.3 },
]

// ── Animation variants ──────────────────────────────────────────────────────

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] } },
}

const stagger = {
  hidden: {},
  show:   { transition: { staggerChildren: 0.08 } },
}

const cardVariant = {
  hidden: { opacity: 0, y: 20 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } },
}

// ── Section header helper ───────────────────────────────────────────────────

function SectionHeader({ icon: Icon, iconColor, badge, title, subtitle, viewAllLink, viewAllLabel = 'View All' }) {
  return (
    <div className="flex items-end justify-between mb-8">
      <div>
        {badge && (
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full border mb-3 ${badge.color}`}>
            <span>{badge.icon}</span> {badge.label}
          </span>
        )}
        <h2 className="font-display font-bold text-2xl sm:text-3xl text-gray-900 flex items-center gap-2">
          {Icon && <Icon className={`w-6 h-6 ${iconColor}`} />}
          {title}
        </h2>
        {subtitle && <p className="text-gray-500 mt-1 text-sm">{subtitle}</p>}
      </div>
      {viewAllLink && (
        <Link
          to={viewAllLink}
          className="hidden sm:inline-flex items-center gap-1.5 text-sm font-semibold text-primary-600 hover:text-primary-700 bg-primary-50 hover:bg-primary-100 border border-primary-200 px-4 py-2 rounded-xl transition-all duration-200"
        >
          {viewAllLabel} <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      )}
    </div>
  )
}

// ── Main Component ──────────────────────────────────────────────────────────

export default function Home() {
  const { getFeaturedTools, getTrendingTools, blogPosts, categories } = useApp()
  const [searchQuery, setSearchQuery] = useState('')
  const [searchFocused, setSearchFocused] = useState(false)
  const navigate = useNavigate()

  const featuredTools  = getFeaturedTools()
  const trendingTools  = getTrendingTools()
  const recentPosts    = blogPosts.slice(0, 6)

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/tools?q=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  return (
    <>
      <SEOHead
        title={null}
        description="Discover 500+ AI tools organized by category. Find the best AI for writing, image generation, video creation, coding, and marketing. Updated daily."
        canonical="/"
        schema={{
          '@context': 'https://schema.org',
          '@type': 'WebSite',
          name: 'AI Tools Hub',
          url: 'https://aitoolshub.com',
          potentialAction: {
            '@type': 'SearchAction',
            target: 'https://aitoolshub.com/tools?q={search_term_string}',
            'query-input': 'required name=search_term_string',
          },
        }}
      />

      {/* ═══════════════════════════════════════════════════════ HERO ══ */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-white pt-16">

        {/* Dot-grid background */}
        <div className="absolute inset-0 dot-grid-bg opacity-60 pointer-events-none" />

        {/* Gradient blobs */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-10 left-1/4 w-[500px] h-[400px] bg-gradient-to-br from-indigo-100/60 to-sky-100/40 rounded-full blur-3xl" />
          <div className="absolute top-32 right-1/4 w-[400px] h-[300px] bg-gradient-to-br from-pink-100/50 to-purple-100/30 rounded-full blur-3xl" />
          <div className="absolute bottom-20 left-1/3 w-[300px] h-[200px] bg-gradient-to-br from-emerald-100/40 to-teal-100/20 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center">

          {/* Floating Badges */}
          <motion.div
            className="flex flex-wrap justify-center gap-2.5 mb-8"
            initial="hidden"
            animate="show"
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.12 } } }}
          >
            {FLOATING_BADGES.map((badge) => (
              <motion.span
                key={badge.label}
                variants={fadeUp}
                className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3.5 py-1.5 rounded-full border shadow-card ${badge.color} animate-badge-bounce`}
              >
                <span>{badge.icon}</span> {badge.label}
              </motion.span>
            ))}
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
            className="font-display font-extrabold text-5xl sm:text-6xl lg:text-7xl text-gray-900 leading-[1.1] mb-6 tracking-tight"
          >
            Discover the Best{' '}
            <span className="relative inline-block">
              <span className="neon-text">AI Tools</span>
              <svg className="absolute -bottom-1 left-0 w-full" height="6" viewBox="0 0 300 6" preserveAspectRatio="none">
                <path d="M0 3 Q75 0 150 3 Q225 6 300 3" stroke="url(#underline-grad)" strokeWidth="2.5" fill="none" strokeLinecap="round" />
                <defs>
                  <linearGradient id="underline-grad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#6366f1" />
                    <stop offset="100%" stopColor="#0ea5e9" />
                  </linearGradient>
                </defs>
              </svg>
            </span>
            <br />
            <span className="gradient-text-warm">to Boost Your Productivity 🚀</span>
          </motion.h1>

          {/* Subheading */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: 0.22 }}
            className="text-gray-500 text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Explore curated AI tools for{' '}
            <span className="text-indigo-600 font-semibold">writing</span>,{' '}
            <span className="text-sky-600 font-semibold">coding</span>,{' '}
            <span className="text-pink-600 font-semibold">design</span>,{' '}
            <span className="text-emerald-600 font-semibold">marketing</span>, and{' '}
            <span className="text-orange-600 font-semibold">automation</span>.
          </motion.p>

          {/* Search Bar */}
          <motion.form
            onSubmit={handleSearch}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: 0.32 }}
            className="flex items-center gap-3 max-w-xl mx-auto mb-6"
          >
            <div className={`relative flex-1 transition-all duration-300 ${searchFocused ? 'scale-[1.02]' : ''}`}>
              <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 pointer-events-none transition-colors ${searchFocused ? 'text-primary-500' : 'text-gray-400'}`} />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setSearchFocused(false)}
                placeholder="Search AI tools by name or use case..."
                className={`w-full bg-white border rounded-2xl pl-12 pr-5 py-4 text-gray-900 placeholder-gray-400 focus:outline-none text-base shadow-card transition-all duration-300 ${
                  searchFocused
                    ? 'border-primary-400 ring-4 ring-primary-100 shadow-hero'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              />
            </div>
            <button type="submit" className="btn-primary py-4 px-6 whitespace-nowrap text-sm shadow-btn">
              Search
            </button>
          </motion.form>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-wrap justify-center gap-3 mb-10"
          >
            <Link to="/tools" className="btn-primary px-8 py-3.5">
              <Zap className="w-4 h-4" />
              Explore Tools
            </Link>
            <Link to="/contact" className="btn-secondary px-8 py-3.5">
              Submit a Tool
              <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>

          {/* Quick Category Pills */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="flex flex-wrap justify-center gap-2 mb-14"
          >
            {CATEGORY_CONFIG.map((cat) => (
              <Link
                key={cat.key}
                to={`/tools?category=${encodeURIComponent(cat.key)}`}
                className={`inline-flex items-center gap-1.5 ${cat.bg} border ${cat.border} ${cat.color} text-sm font-medium px-4 py-1.5 rounded-full transition-all duration-200 hover:shadow-card hover:-translate-y-0.5`}
              >
                <span className="text-base">{cat.emoji}</span>
                <span>{cat.key}</span>
              </Link>
            ))}
          </motion.div>

          {/* Stats Row */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl mx-auto"
          >
            {STATS.map(({ icon: Icon, label, value, color, bg }) => (
              <div key={label} className="bg-white border border-gray-100 rounded-2xl p-4 text-center shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-0.5">
                <div className={`w-9 h-9 ${bg} rounded-xl flex items-center justify-center mx-auto mb-2`}>
                  <Icon className={`w-4.5 h-4.5 ${color}`} />
                </div>
                <div className="font-display font-extrabold text-xl text-gray-900">{value}</div>
                <div className="text-gray-400 text-xs mt-0.5 font-medium">{label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════ AD BANNER TOP ══ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <AdBannerTop />
      </div>

      {/* ═══════════════════════════════════════════════ CATEGORIES ══ */}
      <section className="bg-gray-50 py-16 border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            title="Browse by Category"
            subtitle="Find AI tools for every use case"
            viewAllLink="/tools"
            viewAllLabel="All Tools"
          />

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4"
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-50px' }}
          >
            {CATEGORY_CONFIG.map((cat) => {
              const catData = categories.find(c => c.name === cat.key)
              return (
                <motion.div key={cat.key} variants={cardVariant}>
                  <Link
                    to={`/tools?category=${encodeURIComponent(cat.key)}`}
                    className={`group flex flex-col items-center text-center p-6 bg-white border border-gray-100 rounded-2xl shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300`}
                  >
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${cat.gradient} border ${cat.border} flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-sm`}>
                      {cat.emoji}
                    </div>
                    <h3 className="font-display font-bold text-gray-900 text-sm mb-1">{cat.key}</h3>
                    {catData?.description && (
                      <p className="text-gray-400 text-xs line-clamp-2 leading-relaxed">{catData.description}</p>
                    )}
                    <div className={`mt-3 text-xs font-semibold ${cat.color} flex items-center gap-1 group-hover:gap-2 transition-all`}>
                      {catData?.count ?? '—'} tools <ChevronRight className="w-3 h-3" />
                    </div>
                  </Link>
                </motion.div>
              )
            })}
          </motion.div>
        </div>
      </section>

      {/* ════════════════════════════════════════ FEATURED TOOLS ══ */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            icon={Star}
            iconColor="text-amber-500"
            badge={{ icon: '⭐', label: 'Editor\'s Picks', color: 'text-amber-600 bg-amber-50 border-amber-200' }}
            title="Featured Tools"
            subtitle="Curated picks for every creator"
            viewAllLink="/tools?featured=true"
            viewAllLabel="View All"
          />

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-50px' }}
          >
            {featuredTools.map(tool => (
              <motion.div key={tool.slug} variants={cardVariant}>
                <ToolCard tool={tool} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════ AD IN-CONTENT ══ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdBannerInContent />
      </div>

      {/* ═══════════════════════════════════════════════ TRENDING ══ */}
      <section className="bg-gray-50 py-16 border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            icon={TrendingUp}
            iconColor="text-emerald-500"
            badge={{ icon: '🔥', label: 'Hot This Week', color: 'text-orange-600 bg-orange-50 border-orange-200' }}
            title="Trending Now"
            subtitle="Most viewed tools this week"
            viewAllLink="/tools"
            viewAllLabel="Explore All"
          />

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 gap-3"
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-50px' }}
          >
            {trendingTools.map((tool, idx) => (
              <motion.div key={tool.slug} variants={cardVariant}>
                <Link
                  to={`/tools/${tool.slug}`}
                  className="tool-card flex items-center gap-4 p-4 group"
                >
                  {/* Rank */}
                  <div className={`w-8 font-display font-extrabold text-xl flex-shrink-0 text-center ${
                    idx === 0 ? 'text-amber-500' : idx === 1 ? 'text-gray-400' : idx === 2 ? 'text-orange-400' : 'text-gray-300'
                  }`}>
                    {idx + 1}
                  </div>

                  {/* Logo */}
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-indigo-50 to-sky-50 border border-indigo-100 flex items-center justify-center text-2xl flex-shrink-0">
                    {tool.logo}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="font-display font-semibold text-gray-900 text-sm group-hover:text-primary-600 transition-colors truncate">
                      {tool.name}
                    </div>
                    <div className="text-gray-400 text-xs mt-0.5 truncate">{tool.category}</div>
                  </div>

                  {/* Views */}
                  <div className="flex items-center gap-1.5 text-xs font-medium text-emerald-600 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full flex-shrink-0">
                    <TrendingUp className="w-3 h-3" />
                    {tool.views?.toLocaleString()}
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════ LATEST BLOG ══ */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            icon={Newspaper}
            iconColor="text-sky-500"
            badge={{ icon: '📚', label: 'Fresh Articles', color: 'text-sky-600 bg-sky-50 border-sky-200' }}
            title="Latest Guides & Reviews"
            subtitle="In-depth coverage of the AI landscape"
            viewAllLink="/blog"
            viewAllLabel="All Articles"
          />

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-50px' }}
          >
            {recentPosts.map(post => (
              <motion.div key={post.slug} variants={cardVariant}>
                <BlogCard post={post} />
              </motion.div>
            ))}
          </motion.div>

          <div className="text-center mt-10">
            <Link to="/blog" className="btn-secondary inline-flex items-center gap-2 px-8 py-3.5">
              View All Articles <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════ CTA BANNER ══ */}
      <section className="bg-gray-50 py-16 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-600 via-indigo-600 to-sky-600 p-10 sm:p-14 text-center shadow-hero"
          >
            {/* Decorative dots pattern overlay */}
            <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
              backgroundImage: 'radial-gradient(rgba(255,255,255,0.4) 1px, transparent 1px)',
              backgroundSize: '24px 24px'
            }} />

            {/* Glowing blobs */}
            <div className="absolute top-0 left-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 right-1/4 w-48 h-48 bg-white/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10">
              <div className="inline-flex items-center gap-2 bg-white/15 text-white/90 text-xs font-semibold px-4 py-1.5 rounded-full border border-white/25 mb-6">
                <Bot className="w-3.5 h-3.5" />
                500+ tools & growing daily
              </div>

              <h2 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white mb-4 leading-tight">
                Can't find what you need?
              </h2>
              <p className="text-white/75 text-lg mb-10 max-w-xl mx-auto leading-relaxed">
                Browse our complete directory of 500+ AI tools across every category.
                New tools added every day.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link
                  to="/tools"
                  className="inline-flex items-center gap-2 bg-white text-primary-700 font-bold px-8 py-3.5 rounded-xl shadow-card hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200 text-base"
                >
                  <Zap className="w-4 h-4" />
                  Explore All Tools
                </Link>
                <Link
                  to="/prompts"
                  className="inline-flex items-center gap-2 bg-white/15 hover:bg-white/25 border border-white/30 text-white font-semibold px-8 py-3.5 rounded-xl transition-all duration-200 text-base"
                >
                  Browse Prompts <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  )
}
